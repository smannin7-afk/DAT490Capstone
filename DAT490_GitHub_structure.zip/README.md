# DAT490Capstone

Machine learning approaches for mortgage loan approval prediction using 2023 HMDA data.

For the full reproducibility map, running order, expected data layout, and table/figure output mapping, see:

```text
README_reproducibility.md
```

The raw HMDA LAR file is not committed because it is too large. The expected local path is:

```text
data/raw/2023_public_lar_csv.csv
```
