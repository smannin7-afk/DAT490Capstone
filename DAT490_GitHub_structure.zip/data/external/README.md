# External State Covariates

The multilevel notebook expects:

```text
data/external/state_covariates.csv
```

Expected columns:

```text
state_code,state_median_income,lender_concentration_hhi
```

`state_median_income` comes from the ACS 2022 state median household income source used in the report.

`lender_concentration_hhi` should be computed from the HMDA LAR file by state using lender application shares. For each state, count applications by lender `lei`, divide each lender count by the total state application count, square those shares, and sum them.
