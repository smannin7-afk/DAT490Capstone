import argparse
from pathlib import Path
import pandas as pd

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-lar", default="data/raw/2023_public_lar_csv.csv")
    parser.add_argument("--acs-income", default="data/external/acs_2022_state_median_income.csv")
    parser.add_argument("--output", default="data/external/state_covariates.csv")
    parser.add_argument("--chunksize", type=int, default=500000)
    args = parser.parse_args()

    raw_path = Path(args.raw_lar)
    income_path = Path(args.acs_income)
    out_path = Path(args.output)

    if not raw_path.exists():
        raise FileNotFoundError(f"Missing HMDA LAR file: {raw_path}")
    if not income_path.exists():
        raise FileNotFoundError(
            f"Missing ACS income file: {income_path}. "
            "Expected columns: state_code,state_median_income"
        )

    needed = ["state_code", "lei", "action_taken"]
    counts = []

    for chunk in pd.read_csv(raw_path, usecols=lambda c: c in needed, dtype="string", chunksize=args.chunksize, low_memory=False):
        missing = sorted(set(needed) - set(chunk.columns))
        if missing:
            raise ValueError(f"Missing required columns from HMDA file: {missing}")

        chunk["action_taken_num"] = pd.to_numeric(chunk["action_taken"], errors="coerce")
        chunk = chunk[chunk["action_taken_num"].isin([1, 2, 3])]
        chunk = chunk.dropna(subset=["state_code", "lei"])

        if len(chunk):
            counts.append(chunk.groupby(["state_code", "lei"]).size().reset_index(name="n"))

    if not counts:
        raise ValueError("No rows available to compute lender concentration.")

    lender_counts = pd.concat(counts, ignore_index=True).groupby(["state_code", "lei"], as_index=False)["n"].sum()
    state_totals = lender_counts.groupby("state_code", as_index=False)["n"].sum().rename(columns={"n": "state_n"})
    lender_counts = lender_counts.merge(state_totals, on="state_code", how="left")
    lender_counts["share"] = lender_counts["n"] / lender_counts["state_n"]
    hhi = lender_counts.assign(share_sq=lambda x: x["share"] ** 2).groupby("state_code", as_index=False)["share_sq"].sum()
    hhi = hhi.rename(columns={"share_sq": "lender_concentration_hhi"})

    income = pd.read_csv(income_path, dtype={"state_code": "string"})
    required_income = {"state_code", "state_median_income"}
    missing_income = required_income - set(income.columns)
    if missing_income:
        raise ValueError(f"ACS income file missing columns: {sorted(missing_income)}")

    covariates = income[["state_code", "state_median_income"]].merge(hhi, on="state_code", how="left")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    covariates.to_csv(out_path, index=False)

    print(f"Saved {out_path}")
    print(covariates.head())

if __name__ == "__main__":
    main()
